const express = require('express');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;

// Middleware
app.use(cors({ origin: "*" }));
app.use(express.json());

// Simple logger that logs method, path and final status after response finishes
app.use((req, res, next) => {
  res.on('finish', () => {
    console.log(req.method, req.originalUrl, res.statusCode);
  });
  next();
});

// Routes
app.get("/api/ping", async (req, res) => {
  // Handler for Ping
  const status = 200;
  const body = {
  "pong": true
};
  // Simple per-route logging before sending response
  console.log(req.method, req.path, status);
  res.status(status).json(body);
});

const server = app.listen(PORT, () => {
  // If PORT was 0 (ephemeral), server.address() contains the real port
  const addr = server.address();
  const actualPort = (addr && typeof addr === 'object' && 'port' in addr) ? addr.port : PORT;
  console.log('Server running on port ' + actualPort);
});

// Set a server timeout to guard long-running requests (ms)
server.setTimeout(30000);
